package com.benyanyi.sqlitelib;

import android.content.Context;
import android.text.TextUtils;

import com.benyanyi.sqlitelib.impl.TableDaoImpl;
import com.benyanyi.sqlitelib.impl.TableSessionImpl;

/**
 * @author YanYi
 * @date 2019/5/17 16:14
 * @email ben@yanyi.red
 * @overview
 */
public final class TableDao implements TableDaoImpl {
    private String dbName;
    private int version;
    private Context mContext;
    private TableSession session;

    public static final String DB_NAME = "base_db_db_name";

    private TableDao() {
    }

    private TableDao(Context context, Builder builder) {
        this.mContext = context;
        this.dbName = builder.dbName;
        this.version = builder.version;
        this.session = new TableSession();
    }

    @Override
    public <T> TableSessionImpl<T> getSession(Class<T> tClass) {
        return this.session.init(this.dbName, this.version, this.mContext, tClass);
    }

    public static class Builder {
        private String dbName = null;
        private int version = 1;

        public Builder setDbName(String dbName) {
            this.dbName = dbName;
            return this;
        }

        public Builder setVersion(int version) {
            this.version = version;
            if (this.version < 1) {
                this.version = 1;
            }
            return this;
        }

        public TableDaoImpl builder(Context context) {
            boolean boo = TextUtils.isEmpty(dbName) || "".equals(dbName.trim())
                    || "null".equals(dbName.toLowerCase().trim());
            if (boo) {
                dbName = context.getPackageName() + "_TABLE_DB";
            }
            if (this.version < 1) {
                this.version = 1;
            }
            return new TableDao(context, this);
        }
    }
}
